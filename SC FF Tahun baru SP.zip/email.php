<?php
$emailku = 'emailmu-uhuinfo@gmail.com'; // masukin email lu disini coeng -_-
?>